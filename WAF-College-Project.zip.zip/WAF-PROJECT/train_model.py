import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
import re

# Sample payloads for each attack type
data = [
    # SQL Injection
    ("SELECT * FROM users WHERE id = '1' OR '1'='1';", "SQLi"),
    ("' OR '1'='1' --", "SQLi"),
    ("admin' --", "SQLi"),
    ("' UNION SELECT password FROM users --", "SQLi"),

    # XSS
    ("<script>alert('XSS')</script>", "XSS"),
    ("<IMG SRC=javascript:alert('XSS')>", "XSS"),
    ("<BODY ONLOAD=alert('XSS')>", "XSS"),

    # DoS
    ("POST /login HTTP/1.1\nContent-Length: 10000\n\n" + "A" * 10000, "DoS"),
    ("GET /" + "A" * 5000, "DoS"),
    ("while(true) {}", "DoS"),

    # Benign
    ("Hello, how are you?", "Benign"),
    ("<form method='post'>Submit</form>", "Benign"),
    ("search=weather&location=india", "Benign"),
    ("username=admin&password=1234", "Benign"),
]

# Feature extraction
def extract_features(payload):
    payload = payload.lower()
    return [
        len(payload),
        payload.count("'"),
        payload.count("<"),
        payload.count(">"),
        payload.count("select"),
        payload.count("union"),
        payload.count("script"),
        payload.count("sleep"),
        payload.count("1=1"),
        payload.count("--"),
    ]

# Prepare features and labels
X = [extract_features(payload) for payload, label in data]
y = [label for payload, label in data]

# Split and train
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = RandomForestClassifier(n_estimators=100)
model.fit(X_train, y_train)

# Evaluate
y_pred = model.predict(X_test)
print("🔍 Evaluation Report:")
print(classification_report(y_test, y_pred))

# Save model
joblib.dump(model, "waf_model.pkl")
print("✅ Model saved as waf_model.pkl")

# In train_model.py
import pickle

# After training
with open("waf_model.pkl", "wb") as f:
    pickle.dump(model, f)
