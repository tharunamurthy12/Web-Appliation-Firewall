from flask import Flask, request, jsonify, render_template
import pickle

# Load the trained ML model
with open("waf_model.pkl", "rb") as f:
    model = pickle.load(f)

app = Flask(__name__)

# Track detection statistics
detection_stats = {
    "Benign": 0,
    "SQLi": 0,
    "XSS": 0,
    "DoS": 0
}

# Feature extraction function
def extract_features(payload):
    return [
        len(payload),
        payload.count('"'),
        payload.count("<"),
        payload.count(">"),
        payload.lower().count("select"),
        payload.lower().count("union"),
        payload.lower().count("script"),
        payload.lower().count("alert"),
        payload.lower().count("or"),
        payload.lower().count("and")
    ]

# Homepage route
@app.route("/")
def index():
    return render_template("index.html")

# Predict route
@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json()
    payload = data["payload"]
    features = extract_features(payload)
    prediction = model.predict([features])[0]

    # Update detection stats
    if prediction in detection_stats:
        detection_stats[prediction] += 1

    return jsonify({"prediction": prediction})

# Route to get live statistics
@app.route("/stats")
def stats():
    return jsonify(detection_stats)

# Run the Flask app
if __name__ == "__main__":
    app.run(debug=True)
