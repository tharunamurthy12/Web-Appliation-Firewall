# features.py

def extract_features(payload):
    payload = payload.lower()
    features = [
        len(payload),
        payload.count("'"),
        payload.count("<"),
        payload.count(">"),
        payload.count("select"),
        payload.count("union"),
        payload.count("script"),
        payload.count("sleep"),
        payload.count("1=1"),
        payload.count("--"),
    ]
    return [features]
